/***********************************
*	Programmed by : Sean Vaughan   *
*         CIS278 - Mansour         * 
*      Chapter 6 Exercise 6.58     *
************************************/



#include "pch.h"
#include <iostream>
#include <stdlib.h>

using namespace std;

//Prototypes
int getRandomNum();
void generatePositiveResponse();
void generateNegativeResponse();

//--------------------- MAIN --------------------------
int main()
{

	int userChoice;
	int userNum;

	cout << "Would you like to do some multiplication?(1-Yes/2-No)\n";
	cin >> userChoice;

	//Loops through program while user enters a 1. Ends if user enters a 2.
	while (userChoice == 1) {

		//Declare all variables needed.
		int rand1, rand2, answer;
		int correctAnswer = 2;

		//Get random number methods.
		rand1 = getRandomNum();
		rand2 = getRandomNum();

		//Solution of the 2 random numbers.
		answer = rand1 * rand2;

		//Loop to continue asking the same problem until the user gets it right.
		while (correctAnswer == 2) {
			cout << "\nHow much is " << rand1 << " times " << rand2 << "?\n";
			cin >> userNum;
			
			if (userNum == answer) { //Correct Answer
				generatePositiveResponse();
				correctAnswer = 1;
			}
			else { //Incorrect Answer
				generateNegativeResponse();
			}
		}

		//Asks user if they would like to continue.
		cout << "\nWould you like to do another problem?(1-Yes/2-No)\n";
		cin >> userChoice;
	}
}

//Method to get a random 1 digit number.
int getRandomNum() {
	int num;
	num = rand() % 10 + 1;
	return num;
}

//Method for generating positive reponses.
void generatePositiveResponse() {
	int num;
	num = rand() % 4;
	switch (num)
	{
	case 0:
		cout << "\nVery good!\n";
		break;
	case 1:
		cout << "\nExcellent!\n";
		break;
	case 2:
		cout << "\nNice work!\n";
		break;
	case 3:
		cout << "\nKeep up the good work!\n";
		break;
	default:
		break;
	}
}

//Method for generating negative responses.
void generateNegativeResponse() {
	int num;
	num = rand() % 4;
	switch (num)
	{
	case 0:
		cout << "\nNo. Please try again.\n";
		break;
	case 1:
		cout << "\nWrong. Try once more.\n";
		break;
	case 2:
		cout << "\nDon't give up!\n";
		break;
	case 3:
		cout << "\nNo. Keep trying.\n";
		break;
	default:
		break;
	}
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
