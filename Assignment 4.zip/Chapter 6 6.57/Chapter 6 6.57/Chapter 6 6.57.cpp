/***************************************
*	  Programmed by : Sean Vaughan     *
*          CIS 278 - Mansour           *
*       Chapter 6 Exercise 6.57        *
****************************************/


#include "pch.h"
#include <iostream>
#include <stdlib.h>

using namespace std;

//Prototype for random number method.
int getRandomNum();

//------------------------------ MAIN ----------------------------------
int main()
{
	//Declare user decision making variables.
	int userChoice;
	int userNum;

	cout << "Would you like to do some multiplication?(1-Yes/2-No)\n";
	cin >> userChoice;

	//Loops through program while user inp = 1, ends if user inp = 2.
	while (userChoice == 1) {

		//Declare random variables.
		int rand1, rand2, answer;
		int correctAnswer = 2;

		//Gets 2 random numbers.
		rand1 = getRandomNum();
		rand2 = getRandomNum();

		//Get the solution(product of the random numbers)
		answer = rand1 * rand2;

		//Loop to display the wrong/right prompts until the user answers the problem correctly.
		while (correctAnswer == 2) {
			cout << "\nHow much is " << rand1 << " times " << rand2 << "?\n";
			cin >> userNum;

			if (userNum == answer) { //If user answers correctly
				cout << "\nVery good!\n";
				correctAnswer = 1;
			}
			else { //If user answers incorrectly
				cout << "\nNo. Please try again!\n";
			}
		}

		//Asks user if they would like to answer another problem.
		cout << "\nWould you like to do another problem?(1-Yes/2-No)\n";
		cin >> userChoice;
	}
}
	
//Method for getting a random single digit number.
int getRandomNum() {
	int num;
	num = rand() % 10 + 1;
	return num;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
