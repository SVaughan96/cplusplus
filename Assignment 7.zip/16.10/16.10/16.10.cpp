/******************************
*  Programmer : Sean Vaughan  *
*      CIS 278 - Mansour      *
*       Chapter 16 6.10       *
*******************************/

#include "pch.h"
#include <iostream>
#include <algorithm>
#include <vector>
#include <iterator>
#include <fstream>

using namespace std;


//------------ MAIN ---------------
int main()
{
	//Creates input stream to read from file.
	ifstream myFile("numbers.txt");

	//Creates vector and output iterator
	vector<int> myVector;
	ostream_iterator<int> output(cout, " ");

	if (!myFile) //Always test the file open.
	{
		cout << "Error opening output file" << endl;
		system("pause");
		return -1;
	}

	//Copies contents of the file into the vector using back_inserter
	copy(istream_iterator<int>(myFile),
		istream_iterator<int>(),
		back_inserter(myVector));

	//Closes file
	myFile.close();

	//Prints out the vector with contents of the file.
	cout << "Vector with the contents of the file: ";
	copy(myVector.begin(), myVector.end(), output);
}

