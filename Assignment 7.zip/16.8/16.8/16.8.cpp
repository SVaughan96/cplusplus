/****************************
* Programmer : Sean Vaughan *
*     CIS 278 - Mansour     *
*      Chapter 16 16.8      *
*****************************/

#include "pch.h"
#include <iostream>
#include <array>
#include <algorithm>
#include <iterator>

using namespace std;

//------------MAIN-----------------
int main()
{
	const size_t SIZE{ 20 }; //Array Size
	//Create array and output iterator
	array<int, SIZE> myArray{ 1, 2, 1, 2, 3, 6, 6, 8, 10, 11, 15, 1, 20, 3, 25, 12, 13, 5, 22, 74 };
	ostream_iterator<int> output{ cout, " " };

	//Display initial array using output iterater
	cout << "\nContents of the array before getting rid of duplicates:";
	copy(myArray.begin(), myArray.end(), output);

	//Sort the array
	sort(myArray.begin(), myArray.end());

	//Gets rid of uniques in the array
	auto endLocation = unique(myArray.begin(), myArray.end());

	//Display contents of the new array.
	cout << "\nContents of the array after getting rid of duplicates:";
	copy(myArray.begin(), endLocation, output);



}

