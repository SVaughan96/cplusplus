/****************************
* Programmer : Sean Vaughan *
*     CIS 278 - Mansour     *
*      Chapter 16 16.9      *
*****************************/

#include "pch.h"
#include <iostream>
#include <array>
#include <algorithm>
#include <iterator>
#include <vector>

using namespace std;

//----------------- MAIN ----------------------
int main()
{
	const size_t SIZE{ 20 }; //Declares size of the array.
	//Declare array and output iterator
	array<int, SIZE> myArray{ 1, 2, 1, 2, 3, 6, 6, 8, 10, 11, 15, 1, 20, 3, 25, 12, 13, 5, 22, 74 };
	ostream_iterator<int> output{ cout, " " };

	//Display array before anything done to it, then sort.
	cout << "\nContents of the array before getting rid of duplicates:";
	copy(myArray.begin(), myArray.end(), output);
	sort(myArray.begin(), myArray.end());

	//Creates an empty vector
	vector<int> myVector;

	//Copies only unique values into the vector using back_inserter
	unique_copy(myArray.begin(), myArray.end(), back_inserter(myVector));

	//Display the results of the new vector.
	cout << "\nResults after copying unique values into a vector using back inserter : ";
	copy(myVector.begin(), myVector.end(), output);


}

