/*****************************************************
*			Programmed By : Sean Vaughan			 *
*				CIS 278 - Mansour					 *
*			 Chapter 13 Exercise 13.17				 *
******************************************************/

#include "pch.h"
#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>


using namespace std;

//Method to fill vector
void fillVector(vector<double> &myVector)
{
	cout << "Enter 3 Integers.\n";
	

	for (int i = 0; i < 3; i++) {
		int input;
		cin >> input;
		myVector.push_back(input);
	}

}

//Method to calc mean
double calcMean(vector<double> myVector)
{
	double mean = 0;
	double total = 0;

	for (int i = 0; i < myVector.size(); i++) {
		total += (double)myVector.at(i);
	}

	mean = total / (double)myVector.size();

	return mean;
}

//Method to sort vector
void sortVector(vector<double> &myVector)
{
	bool swap = true;
	while (swap) {
		swap = false;
		for (int i = 0; i < myVector.size() - 1; i++) {
			if (myVector[i] > myVector[i + 1]) {
				myVector[i] += myVector[i + 1];
				myVector[i + 1] = myVector[i] - myVector[i + 1];
				myVector[i] -= myVector[i + 1];
				swap = true;
			}
		}
	}
}

//Method to calc standard deviation
double calcDeviation(double mean, vector<double> &myVector) {
	
	double deviation = 0;
	double deviationSum = 0;
	double cm1 = myVector.size() - 1;

	for (int i = 0; i < myVector.size(); i++) {
		deviationSum += (pow((myVector[i] - mean), 2)) / cm1;
	}
	
	deviation = sqrt(deviationSum);

	return deviation;

}

//Method to display statistics.
void displayStatistics(double mean, int min, int max, int median, double deviation) {

	cout << setprecision(2) << fixed; // Formats numbers to 2 decimal places.

	cout << "Mean               : " << mean << endl;
	cout << "Median             : " << median << endl;
	cout << "Standard Deviation : " << deviation << endl;
	cout << "Min                : " << min << endl;
	cout << "Max                : " << max << endl;

}


//------------------------------- Main -------------------------------------
int main()
{
    //Creates Vector to hold ints.
	vector<double> myVector;

	//Declare variables for statistics.
	int median, min, max;
	double mean, standardDeviation;

	//Fills vector with 3 ints from user.
	fillVector(myVector);

	//Sorts vector for easy access to min/median/max.
	sortVector(myVector);

	//Calc stats
	mean = calcMean(myVector);
	min = (int)myVector.at(0);
	max = (int)myVector.at(2);
	median = (int)myVector.at(1);
	standardDeviation = calcDeviation(mean, myVector);
	
	//Displays results.
	displayStatistics(mean, min, max, median, standardDeviation);


}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

