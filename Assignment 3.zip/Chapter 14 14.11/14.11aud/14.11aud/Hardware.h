#ifndef HARDWARE_H
#define HARDWARE_H

#include <string>


class Hardware
{
public:
	//Default hardware tool constructor.
	Hardware(int = 0, const std::string& = "", int = 0, long double = 0.00);

	//Accessor functions for tool ID
	void setToolID(int);
	int getToolID() const;

	//Accessor functions for tool name.
	void setToolName(const std::string&);
	std::string getToolName() const;



	//Accessor functions for tool quantity.
	void setToolQuantity(int);
	int getToolQuantity() const;

	//Accessor functions for tool cost.
	void setToolCost(long double);
	long double getToolCost() const;

private:
	int toolID;
	char toolName[20];
	int toolAmt;
	long double toolCost;
};

#endif


