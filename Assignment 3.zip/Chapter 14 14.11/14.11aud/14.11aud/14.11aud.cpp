#include "pch.h"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstdlib>
#include "Hardware.h"

using namespace std;

enum class Choice { PRINT = 1, UPDATE, NEW, DELETE, END };

Choice enterChoice();
void createTextFile(fstream&);
void updateRecord(fstream&);
void newRecord(fstream&);
void deleteRecord(fstream&);
void outputLine(ostream&, const Hardware&);
int getRecord(const char* const);

int main()
{

	//open file for reading and writing
	fstream inOutHardware{ "C:/Users/Sean/source/repos/Chapter 14 14.11/hardwareinventory.dat", ios::in | ios::binary };

	//exits program if file cannot be opened
	if (!inOutHardware) {
		cerr << "File could not be opened." << endl;
		exit(EXIT_FAILURE);
	}

	//used to store user choice.
	Choice choice;

	//Used to get action from user.
	while ((choice = enterChoice()) != Choice::END) {
		switch (choice) {
		case Choice::PRINT: //creates text file from record.
			createTextFile(inOutHardware);
			break;
		case Choice::UPDATE: //updates a record.
			updateRecord(inOutHardware);
			break;
		case Choice::NEW: //creates a new record.
			newRecord(inOutHardware);
			break;
		case Choice::DELETE: //deletes existing record.
			deleteRecord(inOutHardware);
			break;
		default:
			cerr << "Incorrect choice" << endl;
			break;
		}

		//resets end-of-file indicator
		inOutHardware.clear();

	}
}

//gets user menu choice
Choice enterChoice() {
	cout << "\nEnter your choice\n"
		<< "1 - store a formatted text file of records\n"
		<< "    called \"print.txt\" for printing\n"
		<< "2 - update a record\n"
		<< "3 - add a new record\n"
		<< "4 - delete a record\n"
		<< "5 - end program\n?";

	int menuChoice;
	cin >> menuChoice;
	return static_cast<Choice>(menuChoice);
}

//formatted text file to show info on RAF file.
void createTextFile(fstream& readFromFile) {

	//Creates file for the text file.
	ofstream outPrintFile("print.txt", ios::out);

	//Exits if cannot find file.
	if (!outPrintFile) {
		cerr << "File could not be created." << endl;
		exit(EXIT_FAILURE);
	}

	//Print header.
	outPrintFile << left << setw(10) << "Record #" << setw(20) << "Tool Name" << setw(8) << "Quantity" << setw(10) << right << "Cost\n";

	//Sets file pointer to beginning of file.
	readFromFile.seekg(0);

	//Reads first record from RAF.
	Hardware hardware;
	readFromFile.read(reinterpret_cast<char*>(&hardware), sizeof(Hardware));

	//Copies all record onto the text file.
	while (!readFromFile.eof()) {
		if (hardware.getToolID() != 0) {
			outputLine(outPrintFile, hardware);
		}

		readFromFile.read(reinterpret_cast<char*>(&hardware), sizeof(Hardware));
	}
}

//Updates a current record.
void updateRecord(fstream& updateFile) {
	//Gets number of record wanting to be updated.
	int recordNumber{ getRecord("Enter record to update") };

	//Create record object and read first record from RAF.
	updateFile.seekg((recordNumber - 1) * sizeof(Hardware));

	//Read record from file.
	Hardware hardware;
	updateFile.read(reinterpret_cast<char*>(&hardware), sizeof(Hardware));

	//Update record
	if (hardware.getToolID() != 0) {
		outputLine(cout, hardware);

		string toolName;
		int toolQuant;
		double toolPrice;
		cout << "Enter new name(quoted), amount, and price\n";
		cin >> quoted(toolName) >> toolQuant >> toolPrice;

		hardware.setToolName(toolName);
		hardware.setToolQuantity(toolQuant);
		hardware.setToolCost(toolPrice);

		outputLine(cout, hardware);

		//Moves position pointer to correct record in file.
		updateFile.seekp((recordNumber - 1) * sizeof(Hardware));

		//Write updated record over old record in file.
		updateFile.write(reinterpret_cast<const char*>(&hardware), sizeof(Hardware));
	}
	else { //Displays error if account doesn't exist.
		cerr << "Record #" << recordNumber << " has no information." << endl;
	}
}

//Create and insert record.
void newRecord(fstream& insertInFile) {

	//Obatin record num from user.
	int recordNumber{ getRecord("Enter new record number") };

	//Move file pointer to correct record in RAF.
	insertInFile.seekg((recordNumber - 1) * sizeof(Hardware));

	//Read record from file.
	Hardware hardware;
	insertInFile.read(reinterpret_cast<char*>(&hardware), sizeof(Hardware));

	//Create record, if record doesn't exist.
	if (hardware.getToolID() == 0) {
		string toolName;
		int toolQuant;
		double toolCost;

		cout << "Enter new name(quoted), amount, and price\n?";
		cin >> quoted(toolName) >> toolQuant >> toolCost;

		//Sets values
		hardware.setToolName(toolName);
		hardware.setToolQuantity(toolQuant);
		hardware.setToolCost(toolCost);

		//Move position pointer to correct record in file
		insertInFile.seekp((recordNumber - 1) * sizeof(Hardware));

		//Insert record into file.
		insertInFile.write(reinterpret_cast<const char*>(&hardware), sizeof(Hardware));

	}
	else { //display error message if record already exists.
		cerr << "Record # " << recordNumber << " already contains information." << endl;
	}

}

//Delete an existing record.
void deleteRecord(fstream& deleteFromFile) {

	//Gets user record choice.
	int recordNumber{ getRecord("Enter record to delete") };

	//Move position pointer to correct record in file.
	deleteFromFile.seekg((recordNumber - 1) * sizeof(Hardware));

	//Read record from file.
	Hardware hardware;
	deleteFromFile.read(reinterpret_cast<char*>(&hardware), sizeof(hardware));

	//Delete record if it exists.
	if (hardware.getToolID() != 0) {
		Hardware emptyHardware;

		//move position pointer to correct record.
		deleteFromFile.seekp((recordNumber - 1) * sizeof(Hardware));

		//replace existing with a blank record.
		deleteFromFile.write(reinterpret_cast<const char*>(&emptyHardware), sizeof(Hardware));

		cout << "Record #" << recordNumber << " deleted.\n";
	}
	else { //Display error if record doesn't exist.
		cerr << "Record #" << recordNumber << " is empty.\n";
	}
}

//Displays single record.
void outputLine(ostream& output, const Hardware& record) {

	output << left << setw(10) << record.getToolID() << setw(20) << record.getToolName()
		<< setw(8) << record.getToolQuantity() << setw(10) << setprecision(2) << right << fixed << record.getToolCost() << endl;

}

//Obtains account number value from user.
int getRecord(const char* const prompt) {
	int recordNumber;

	do {
		cout << prompt << "(1-100): ";
		cin >> recordNumber;
	} while (recordNumber < 1 || recordNumber > 100);

	return recordNumber;
}
