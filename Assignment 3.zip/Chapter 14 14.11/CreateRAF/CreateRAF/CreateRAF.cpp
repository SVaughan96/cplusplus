/**************************************
*	  Programmer : Sean Vaughan       *
*         CIS 278 - Mansour           *
*     Chapter 14 Exercise 14.11       *
***************************************/

#include "pch.h"
#include <iostream>
#include <fstream>
#include <cstdlib>
#include "Hardware.h"

using namespace std;

int main()
{
	ofstream outHardware{ "C:/Users/Sean/source/repos/Chapter 14 14.11/hardwareinventory.dat", ios::out | ios::binary };

	//Exits program if ofstream could not open file
	if (!outHardware) {
		cerr << "File could not be opened." << endl;
		exit(EXIT_FAILURE);
	}

	Hardware blankTool;

	for (int i{ 0 }; i < 100; ++i) {
		outHardware.write(reinterpret_cast<const char*>(&blankTool), sizeof(Hardware));
	}
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
