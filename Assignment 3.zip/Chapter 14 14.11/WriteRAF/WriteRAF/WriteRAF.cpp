#include "pch.h"
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <iomanip>
#include "Hardware.h"

using namespace std;

int main() {

	ofstream outHardware{ "C:/Users/Sean/source/repos/Chapter 14 14.11/hardwareinventory.dat", ios::in || ios::out || ios::binary };

	//Exits program if fstream cannot open file.
	if (!outHardware) {
		cerr << "File could not be opened." << endl;
		exit(EXIT_FAILURE);
	}

	cout << "Enter tool ID(1 to 100, 0 to end input)\n?";

	int toolID, toolAmt;
	string toolName;
	double toolCost;

	cin >> toolID;

	//User enters information to copy into file.
	while (toolID > 0 && toolID <= 100) {
		//Gets input for tool name, quantity, cost.
		cout << "Enter tool name(in quotes), quantity, and cost.\n?";
		cin >> quoted(toolName) >> toolAmt >> toolCost;

		//Creates tool object.
		Hardware tool{ toolID, toolName, toolAmt, toolCost };

		//Seeks position in file of user-specified record.
		outHardware.seekp((tool.getToolID() - 1) * sizeof(Hardware));

		//Writes user-specified information in file.
		outHardware.write(reinterpret_cast<const char*>(&tool), sizeof(Hardware));

		//Enables user to enter another tool.
		cout << "Enter tool ID\n?";
		cin >> toolID;
	}

	outHardware.close();

}
