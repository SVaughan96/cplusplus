#include "pch.h"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdlib>
#include "Hardware.h"


using namespace std;

void outputLine(ostream& output, const Hardware& record);


int main() {

	ifstream inHardware{ "C:/Users/Sean/source/repos/Chapter 14 14.11/hardwareinventory.dat", ios::in | ios::binary };

	if (!inHardware) {
		cerr << "File could not be opened." << endl;
		exit(EXIT_FAILURE);
	}

	//Output headers
	cout << left << setw(10) << "Record #" << setw(20) << "Tool Name" << setw(8) << "Quantity" << setw(10) << right << "Cost\n";

	//Creates record
	Hardware tool;

	//Read first record from file
	inHardware.read(reinterpret_cast<char*>(&tool), sizeof(Hardware));

	//Read all record from file
	while (inHardware) {
		//Displays record
		if (tool.getToolID() != 0) {
			outputLine(cout, tool);
		}

		//Read next from file
		inHardware.read(reinterpret_cast<char*>(&tool), sizeof(Hardware));
	}

	inHardware.close();

}

void outputLine(ostream& output, const Hardware& record)
{
	output << left << setw(10) << record.getToolID() << setw(20) << record.getToolName()
		<< setw(8) << record.getToolQuantity() << setw(10) << setprecision(2) << right << fixed << record.getToolCost() << endl;
}

