#include "pch.h"
#include "Hardware.h"

using namespace std;

//Default hardware constructor
Hardware::Hardware(int toolIDVal, const string& toolNameVal, int toolAmtVal, double toolCostVal){
	//:toolID(toolIDVal), toolAmt(toolAmtVal), toolCost(toolCostVal) {
	setToolID(toolIDVal);
	setToolName(toolNameVal);
	setToolQuantity(toolAmtVal);
	setToolCost(toolCostVal);
}


//Get tool ID value
int Hardware::getToolID()const {
	return toolID;
}

//Set tool ID value
void Hardware::setToolID(int toolIDVal) {
	toolID = toolIDVal;
}

//Get tool name
string Hardware::getToolName()const {
	return toolName;
}

//Set tool name
void Hardware::setToolName(const string& toolNameVal) {
	size_t length{ toolNameVal.size() };
	length = (length < 20 ? length : 14);
	toolNameVal.copy(toolName, length);
	toolName[length] = '\0';
}

//Get tool quantity value
int Hardware::getToolQuantity()const {
	return toolAmt;
}

//Set tool quantity value
void Hardware::setToolQuantity(int toolAmtVal) {
	toolAmt = toolAmtVal;
}

//Get tool cost value
double Hardware::getToolCost()const {
	return toolCost;
}

//Set tool cost value
void Hardware::setToolCost(double toolCostVal) {
	toolCost = toolCostVal;
}
