#ifndef PROGRAM_H
#define PROGRAM_H

class Date
{
public:
	//Default constructor
	Date(int = 0, int = 0, int = 0);

	//Getters
	int getMonth();
	int getDay();
	int getYear();

	//Setters
	void setMonth(int);
	void setDay(int);
	void setYear(int);

	//Leap year header
	void determineLeapYear();


private:
	//Declare fields
	int month;
	int day;
	int year;
	int isLeapYear;
};

#endif

