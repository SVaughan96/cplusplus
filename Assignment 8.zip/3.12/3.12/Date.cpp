#include "pch.h"
#include "Date.h"
#include <iostream>

//Custom constructor
Date::Date(int currMonth, int currDay, int currYear)
{
	setMonth(currMonth);
	setYear(currYear);
	setDay(currDay);
}

//Method to return the month
int Date::getMonth() {
	return month;
}

//Method to return the day
int Date::getDay() {
	return day;
}

//Method to return the year
int Date::getYear() {
	return year;
}

//Method to set a valid month.
void Date::setMonth(int currMonth) {
	if (currMonth > 0 && currMonth <= 12) {
		month = currMonth;
	}
	else {
		month = 1;
	}
}

//Method to set a valid year, if not valid sets to current year.
void Date::setYear(int currYear) {
	if (currYear > -2000 && currYear <= 2019) {
		year = currYear;
	}
	else {
		year = 2019;
	}

}

//Method to set the a valid day.
void Date::setDay(int currDay) {
	determineLeapYear();
	if (month == 2 && isLeapYear == 1 && (currDay > 0 && currDay <= 29)) {
		day = currDay;
	}
	else if (month == 2 && isLeapYear == 0 && (currDay > 0 && currDay <= 28)) {
		day = currDay;
	}
	else if ((month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) &&
		(currDay > 0 && currDay <= 31)) {
		day = currDay;
	}
	else if ((month == 4 || month == 6 || month == 9 || month == 11) && (currDay > 0 && currDay <= 30)) {
		day = currDay;
	}
	else {
		day = 1;
	}

}

//Method to determine if the year is a leap year.
void Date::determineLeapYear() {
	if (year % 4 == 0)
	{
		if (year % 100 == 0)
		{
			if (year % 400 == 0)
			{
				isLeapYear = 1;
			}
			else 
			{
				isLeapYear = 0;
			}
		}
		else {
			isLeapYear = 1;
		}
	}else{
		isLeapYear = 0;

	}
}



