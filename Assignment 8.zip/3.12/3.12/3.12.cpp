/******************************
*  Programmer : Sean Vaughan  *
*      CIS 278 - Mansour      *
*     Chapter 3 - 3.12        *
*******************************/

#include "pch.h"
#include <iostream>
#include "Date.h"
#include <list>
#include <iomanip>

using namespace std;

//Protoypes
void printDates(list<Date> dateList);

int main()
{
	//creates an empty list of dates.
	list<Date> dateList;

	//create some date objects.
	Date date1(2, 29, 2012);
	Date date2(2, 29, 1999);
	Date date3(1, 31, 2018);
	Date date4(4, 30, 2019);
	Date date5(13, 35, 2020);
	Date date6(1, 15, 1965);
	Date date7(12, 12, 1920);

	//Add date objects to list.
	dateList.push_back(date1);
	dateList.push_back(date2);
	dateList.push_back(date3);
	dateList.push_back(date4);
	dateList.push_back(date5);
	dateList.push_back(date6);
	dateList.push_back(date7);

	cout << "Invalid months and days convert to 1, invalid years convert to the current year.\n\n";
	//Prints the list of dates
	printDates(dateList);
    
}

//Method to print out dates
void printDates(list<Date> dateList) {
	int counter = 1;
	for (Date e : dateList) {
		cout << "Date #" << counter << ": ";
		cout << e.getMonth() << "/" << e.getDay() << "/" << e.getYear() << endl;
		counter++;
	}
}

