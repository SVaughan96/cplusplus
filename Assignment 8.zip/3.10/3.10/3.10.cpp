/******************************
*  Programmer : Sean Vaughan  *
*      CIS 278 - Mansour      *
*       Chapter 3 3.10        *
*******************************/

#include "pch.h"
#include <iostream>
#include "Invoice.h"
#include <list>
#include <iomanip>

using namespace std;

//Prototypes
void displayInvoices(list<Invoice> invoiceList);

int main()
{
	//Create a list to hold the invoice objects.
	list <Invoice> invoiceList;

	//Create a few invoice objects.
	Invoice invoice("B000123", "A red balloon", 5, 1.25);
	Invoice invoice1("B000124", "A big red balloon", 2, 2.25);
	Invoice invoice2("B000133", "A blue balloon", 7, 1.25);
	Invoice invoice3("B000134", "A big blue balloon", 4, 2.25);
	Invoice invoice4("B999999", "A golden balloon", 1, 1000.00);

	invoice4.setDiscount(500);

	//Add invoiced to the list.
	invoiceList.push_back(invoice);
	invoiceList.push_back(invoice1);
	invoiceList.push_back(invoice2);
	invoiceList.push_back(invoice3);
	invoiceList.push_back(invoice4);


	//Calls method to display invoices
	displayInvoices(invoiceList);

	
}

//Method to print invoices
void displayInvoices(list<Invoice> invoiceList) {
	
	//Counter to keep track of invoices, I know its unorthadox, normally I would assume there would be a invoice number.
	int counter = 1;

	//For each loop to print contents of each invoice
	for (Invoice invoice : invoiceList) {
		cout << "Invoice #        : " << counter << "\n\n";
		cout << "Part Number      : " << invoice.getPartNumber() << endl;
		cout << "Part Description : " << invoice.getPartDescript() << endl;
		cout << "Item Quantity    : " << invoice.getItemQuantity() << endl;
		cout << "Price            : " << setprecision(2) << fixed << invoice.getPricePerItem() << endl;
		cout << "Tax              : " << setprecision(2) << fixed << invoice.getTaxRate() << endl;
		cout << "Discount         : " << setprecision(2) << fixed << invoice.getDiscount() << endl;
		cout << "Invoice Amount   : " << setprecision(2) << fixed << invoice.calcInvoiceAmt() << "\n\n-------------------------\n";
		counter++;
	}
}

