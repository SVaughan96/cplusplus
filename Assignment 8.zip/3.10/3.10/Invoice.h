#ifndef INVOICE_H
#define INVOICE_H

#include <string>

using namespace std;

class Invoice
{
public:
	//Default constructor
	Invoice(const string& = "", const string& = "", int = 0, double = 0.00);

	//Setters
	void setPartNumber(string);
	void setPartDescript(string);
	void setItemQuantity(int);
	void setPricePerItem(double);
	void setTaxRate(double);
	void setDiscount(double);
	//Getters
	string getPartNumber() ;
	string getPartDescript() ;
	int getItemQuantity() ;
	double getPricePerItem() ;
	double getTaxRate() ;
	double getDiscount() ;

	//Alt Methods
	void setInvoiceAmt(double);
	double calcInvoiceAmt() ;



private:
	//Declare all fields
	string partNumber;
	string partDescript;
	int itemQuantity;
	double pricePerItem;
	double taxRate;
	double discount;
	double invoiceAmt;

};

#endif



