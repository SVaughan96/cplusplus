#include "pch.h"
#include "Invoice.h"
#include <string>

using namespace std;

//Constructor for invoice object
Invoice::Invoice(const string& partNum, const string& partDescript, int itemQuant, double pricePerItem)
{
	setPartNumber(partNum);
	setPartDescript(partDescript);
	setItemQuantity(itemQuant);
	setPricePerItem(pricePerItem);
	setTaxRate(0.20);
	setDiscount(0.00);
}

//-------------- GETTERS AND SETTERS ---------------------
void Invoice::setPartNumber(string partNum) {
	partNumber = partNum;
}

void Invoice::setPartDescript(string partDes) {
	partDescript = partDes;
}

void Invoice::setItemQuantity(int itemQuant) {
	if (itemQuant >= 0) {
		itemQuantity = itemQuant;
	}
}

void Invoice::setPricePerItem(double pricePer) {
	if (pricePer > 0) {
		pricePerItem = pricePer;
	}
}

void Invoice::setTaxRate(double tax) {
	taxRate = tax;
}

void Invoice::setDiscount(double discountR) {
	discount = discountR;
}

void Invoice::setInvoiceAmt(double invoiceAmount) {
	invoiceAmt = invoiceAmount;
}

string Invoice::getPartNumber()  {
	return partNumber;
}

string Invoice::getPartDescript()  {
	return partDescript;
}

int Invoice::getItemQuantity()  {
	return itemQuantity;
}

double Invoice::getPricePerItem()  {
	return pricePerItem;
}

double Invoice::getTaxRate()  {
	return taxRate;
}

double Invoice::getDiscount()  {
	return discount;
}
//-------------- END GETTERS AND SETTERS -----------------------

//Calc invoice method
double Invoice::calcInvoiceAmt()  {
	if (discount == 0) {
		double costBeforeTax = (itemQuantity * pricePerItem);
		double invoiceAmt = costBeforeTax + (costBeforeTax * taxRate);
		return invoiceAmt;
	}
	else {
		double costBeforeDiscount = (itemQuantity * pricePerItem);
		double costAfterDiscount = costBeforeDiscount - discount;
		double invoiceAmt = costAfterDiscount + (costAfterDiscount * taxRate);
		return invoiceAmt;
	}
}


