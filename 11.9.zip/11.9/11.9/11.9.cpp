/******************************
*  Programmer : Sean Vaughan  *
*      CIS 278 - Mansour      *
*      Chapter 11: 11.9       *
*******************************/

#include "pch.h"
#include <iostream>
#include <chrono>
#include <thread>
#include "Package.h"
#include "OvernightPackage.h"
#include "TwoDayPackage.h"

using namespace std;

int main()
{
	//Create 1 of each package object.
	Package p1("Sean","Tim","9000 Leet St.","1337 Leet St.","Tucson",
		"Vail","Az","Az", 85730, 85747, 100.00, 0.25);
	TwoDayPackage p2("Bob", "Jim", "9111 Leet St.", "6996 Leet St.", "Tucson",
		"Wakanda", "Az", "Fv", 85730, 13337, 100.00, 0.25, 5.00);
	OvernightPackage p3("Joe", "Rick", "9000 Leet St.", "1000 Leet St.", "Tucson",
		"San Diego", "Az", "Ca", 85730, 12345, 100.00, 0.25, 0.15);

	//Calc costs for packages.
	cout << "Calculating cost for package p1...\n";
	this_thread::sleep_for(chrono::milliseconds(1000)); //Pause for 1 second
	double p1Cost = p1.calculateCost();

	cout << "\nCalculating cost for package p2...\n";
	this_thread::sleep_for(chrono::milliseconds(1000));
	double p2Cost = p2.calculateCost();

	cout << "\nCalculating cost for package p3...\n";
	this_thread::sleep_for(chrono::milliseconds(1000));
	double p3Cost = p3.calculateCost();

	//Print p1
	cout << "-----------------------------------------------\n\n";
	cout << "		   Package Info " << endl;
	cout << "-Sender Information-" << endl;
	cout << "Name             : " << p1.getSenderName() << endl;
	cout << "Address          : " << p1.getSenderAddress() << endl;
	cout << "City, State      : " << p1.getSenderCity() << ", " << p1.getSenderState() << endl;
	cout << "Zip              : " << p1.getSenderZip() << endl;
	cout << "\n-Recipent Information-" << endl;
	cout << "Name             : " << p1.getRecieverName() << endl;
	cout << "Address          : " << p1.getRecieverAddress() << endl;
	cout << "City, State      : " << p1.getRecieverCity() << ", " << p1.getRecieverState() << endl;
	cout << "Zip              : " << p1.getRecieverZip() << endl;
	cout << "\n-Package Information-" << endl;
	cout << "Package Weight   : " << p1.getPackageWeight() << "oz" << endl;
	cout << "Cost Per Ounce   : $" << p1.getCostPerOunce() << endl;
	cout << "\nPackage 1 Cost   : $" << p1Cost << endl;

	//Print p2
	cout << "----------------------------------------------\n\n";
	cout << "		   Package Info " << endl;
	cout << "-Sender Information-" << endl;
	cout << "Name             : " << p2.getSenderName() << endl;
	cout << "Address          : " << p2.getSenderAddress() << endl;
	cout << "City, State      : " << p2.getSenderCity() << ", " << p2.getSenderState() << endl;
	cout << "Zip              : " << p2.getSenderZip() << endl;
	cout << "\n-Recipent Information-" << endl;
	cout << "Name             : " << p2.getRecieverName() << endl;
	cout << "Address          : " << p2.getRecieverAddress() << endl;
	cout << "City, State      : " << p2.getRecieverCity() << ", " << p2.getRecieverState() << endl;
	cout << "Zip              : " << p2.getRecieverZip() << endl;
	cout << "\n-Package Information-" << endl;
	cout << "Package Weight   : " << p2.getPackageWeight() << "oz" << endl;
	cout << "Cost Per Ounce   : $" << p2.getCostPerOunce() << endl;
	cout << "Two Day Fee      : $" << p2.getTwoDayFee() << endl;
	cout << "\nPackage 2 Cost   : $" << p2Cost << endl;

	//Print p3
	cout << "---------------------------------------------\n\n";
	cout << "		   Package Info " << endl;
	cout << "-Sender Information-" << endl;
	cout << "Name             : " << p3.getSenderName() << endl;
	cout << "Address          : " << p3.getSenderAddress() << endl;
	cout << "City, State      : " << p3.getSenderCity() << ", " << p3.getSenderState() << endl;
	cout << "Zip              : " << p3.getSenderZip() << endl;
	cout << "\n-Recipent Information-" << endl;
	cout << "Name             : " << p3.getRecieverName() << endl;
	cout << "Address          : " << p3.getRecieverAddress() << endl;
	cout << "City, State      : " << p3.getRecieverCity() << ", " << p3.getRecieverState() << endl;
	cout << "Zip              : " << p3.getRecieverZip() << endl;
	cout << "\n-Package Information-" << endl;
	cout << "Package Weight   : " << p3.getPackageWeight()  << "oz" << endl;
	cout << "Cost Per Ounce   : $" << p3.getCostPerOunce() << endl;
	cout << "Overnight per/oz : $" << p3.getOvernightCostPerOunce() << endl;
	cout << "\nPackage 3 Cost   : $" << p3Cost << endl;
	
}
