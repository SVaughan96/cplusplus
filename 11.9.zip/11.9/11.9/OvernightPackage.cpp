#include "pch.h"
#include "OvernightPackage.h"

//Default constructor
OvernightPackage::OvernightPackage() {

}

//Constructor
OvernightPackage::OvernightPackage(string senderName, string recieverName, string senderAddress,
	string recieverAddress, string senderCity, string recieverCity,
	string senderState, string recieverState, int senderZip, int recieverZip,
	double packageWeight, double costPerOunce, double overnightCostPerOunce) 
	: Package(senderName, recieverName, senderAddress, recieverAddress, 
		senderCity, recieverCity, senderState, recieverState,
		senderZip, recieverZip, packageWeight, costPerOunce)
{
	setOvernightCostPerOunce(overnightCostPerOunce);
}

//Deconstructor
OvernightPackage::~OvernightPackage()
{
}

//Getters and Setters
void OvernightPackage::setOvernightCostPerOunce(double overnightCostPerOunce) {
	this->overnightCostPerOunce = overnightCostPerOunce;
}
double OvernightPackage::getOvernightCostPerOunce() {
	return this->overnightCostPerOunce;
}

//Calculate cost method
double OvernightPackage::calculateCost() {

	//Get overall cost per ounce on overnight shipping
	double overallCostPerOunce = this->overnightCostPerOunce + getCostPerOunce();

	//Calc total cost
	double totalCost = getPackageWeight() * overallCostPerOunce;

	return totalCost;
}
