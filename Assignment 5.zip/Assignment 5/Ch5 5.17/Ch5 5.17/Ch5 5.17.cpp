/*****************************
*  Programmer : Sean Vaughan *
*     CIS 278 - Mansour      *
*  Chapter 5 : Exercise 5.17 *
******************************/
#include "pch.h"
#include <iostream>
#include <array>
#include <iomanip>

using namespace std;

//Constants used for creating product pricing.
const float PRODUCT_1 = 2.98;
const float PRODUCT_2 = 4.50;
const float PRODUCT_3 = 9.98;
const float PRODUCT_4 = 4.49;
const float PRODUCT_5 = 6.87;
const int MAX_PRODUCT_NUM = 5;
const int MIN_PRODUCT_NUM = 1;
const int MIN_PRODUCT_QUANT = 1;

//Prototypes
int getProductNum();
void displayProducts(float productList[]);
int getProductQuantity();
double determineTotalSale(int productNumber, int productQuant, float totalSale);

//--------------------- MAIN -------------------
int main()
{
	//Declare all variables
	int userBool = 1;
	int productNum, productQuantity;
	float totalSale = 0;
	float productList[5] = { PRODUCT_1, PRODUCT_2, PRODUCT_3, PRODUCT_4, PRODUCT_5 };

	//Program Loop
	do {
		//Displays the list of products.
		displayProducts(productList);

		//Gets the product number
		productNum = getProductNum();

		//Gets the product quantity
		productQuantity = getProductQuantity();

		//Determines total sale based off product/how many and accumulates the total.
		totalSale = determineTotalSale(productNum, productQuantity, totalSale);

		//Asks user if they would like to add another item the the cart.
		cout << "\nWould you like to add more product(s) to your cart? (1 to continue)\n";
		cin >> userBool;

	} while (userBool == 1);

	//Display total retail value.
	cout << "\nTotal Retail Value for products in cart : $" << totalSale << endl;

	//Goodbye message
	cout << "\nGoodbye, please come again!\n";
}

//Method for determining the total sale.
double determineTotalSale(int productNumber, int productQuant, float totalSale) {
	
	switch (productNumber) {
	case 1: //Product num 1
		totalSale += (productQuant * PRODUCT_1);
		break;
	case 2: //Product num 2
		totalSale += (productQuant * PRODUCT_2);
		break;
	case 3: //Product num 3
		totalSale += (productQuant * PRODUCT_3);
		break;
	case 4: //Product num 4
		totalSale += (productQuant * PRODUCT_4);
		break;
	case 5: //Product num 5
		totalSale += (productQuant * PRODUCT_5);
		break;
	default:
		break;
	}

	return totalSale;

}

//Method to display list of products to the user.
void displayProducts(float productList[]) {

	//For loops displaying each product.
	for (int i = 1; i <= 5; i++) {
		
		cout << "Product " << i << ": " << productList[i - 1] << endl;
		
	}
}

//Method to get the quantity of products from user.
int getProductQuantity() {

	int quantity;

	cout << "\nHow many of this product would you like to purchase?\n";
	cin >> quantity;

	//Checks to make sure its a number greater than 0.
	while (quantity < MIN_PRODUCT_QUANT) {
		cout << "\nPlease enter a valid quantity.\n";
		cin >> quantity;
	}

	return quantity;
}

//Method to get the product number from user.
int getProductNum() {

	int productNum;

	cout << "\nPlease choose the product you would like to purchase.\n";
	cin >> productNum;

	//Checks to make sure its a value product number.
	while (productNum < MIN_PRODUCT_NUM || productNum > MAX_PRODUCT_NUM) {
		cout << "\nPlease enter a valid product number.\n";
		cin >> productNum;
	}

	return productNum;

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
