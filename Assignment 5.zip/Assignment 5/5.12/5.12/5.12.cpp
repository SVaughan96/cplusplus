/*******************************
*  Programmer : Sean Vaughan   *
*     CIS 278 - Mansour        *
*   Chapter 5 Excercise 5.12   *
********************************/

#include "pch.h"
#include <iostream>

using namespace std;

//--------- MAIN ---------
int main()
{
	int total = 0;

	//Loop to print each even integer from 2 to 10.
	for (int i = 2; i <= 10; i += 2) {
		total += i;
		cout << "Number: " << i << endl;
	}

	//Prints out the sum of the even integers.
	cout << "The total of these numbers is " << total << ".\n";
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
