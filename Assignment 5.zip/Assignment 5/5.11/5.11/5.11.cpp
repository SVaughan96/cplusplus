/*****************************
*  Programmer : Sean Vaughan *
*      CIS 278 - Mansour     *
*  Chapter 5 Assignment 5.11 *
******************************/

#include "pch.h"
#include <iostream>
#include <vector>

using namespace std;

//Prototypes
int determineNbrOfInts();
void getUserNumbers(vector<int> &numbers, int nbrOfInt);
int determineLowestNum(vector<int> &numbers);

//------------------- MAIN ---------------------
int main()
{
	//Declare variable and vector to hold user numbers.
	int nbrOfInts, lowestNum;
	vector <int> numbers;

	//Gets amount of integers from user.
	nbrOfInts = determineNbrOfInts();

	//Gets ints from user and add them to vector
	getUserNumbers(numbers,nbrOfInts);

	//Determines lowest number out of ints given by user.
	lowestNum = determineLowestNum(numbers);

	//Prints out lowest num.
	cout << "The lowest number you entered was : " << lowestNum << endl;

}

//Methd for determining the lowest number.
int determineLowestNum(vector<int> &numbers) {

	int low = numbers.at(0);

	for (int i = 1; i < numbers.size(); i++) {
		if (low > numbers.at(i)) {
			low = numbers.at(i);
		}
	}

	return low;
}

//Method to get numbers from the user.
void getUserNumbers(vector<int> &numbers, int nbrOfInt) {

	int userNum;

	for (int i = 1; i <= nbrOfInt; i++) {
		cout << "Please enter number " << i << ".\n";
		cin >> userNum;

		numbers.push_back(userNum);
	}

}

//Method to determine how many ints to ask for.
int determineNbrOfInts() {

	int newVal;

	cout << "Please enter how many integers you would like to enter.\n";
	cin >> newVal;

	return newVal;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

