/******************************
*  Programmer : Sean Vaughan  *
*      CIS 278 - Mansour      *
*     Chapter 21 : 21.12      *
*******************************/
#include "pch.h"
#include <iostream>
#include <string>
#include <vector>
#include <fstream>

using namespace std;

//Prototypes
void printStatistics(string fileStr);
void eraseDuplicates(vector<char> &charVector, vector<int> &charCountVector);

int main()
{

	//Creates file reader and string for user file input
	ifstream file;
	string fileString;
	string stringFromFile;

	//Asks user for string input to open a file.
	cout << "Please enter the name of the file you would like to read in a .txt format.\n";
	cout << "Also, note that the file must be in the same folder as this program.\n";
	cin >> fileString;

	//Opens the file.
	file.open(fileString.c_str());

	//Checks to see if file is open.
	if (file.is_open()) {

		//Reads through file until the end.
		while (!file.eof()) {

			file >> stringFromFile; //Inputs line from file into a string.

			//Prints out stats about that string.
			printStatistics(stringFromFile);

		}

		//Closes file.
		file.close();
	}
	else { //If file cannot be opened.
		cout << "Could not open your file for reading.\n";
	}
	

}

void printStatistics(string fileStr) {

	//Create vectors to hold different chars and char counts.
	vector <char> charVector;
	vector <int> charCountVector;

	//Loops through user string to get chars and their counts.
	for (int i = 0; i < fileStr.size(); i++) {

		//Gets a char to work with and assigns initial count to 0.
		char charToCheck = fileStr.at(i);
		int charCount = 0;

		//Loops through the string to get how many times the char appears in the string.
		for (int j = 0; j < fileStr.size(); j++) {
			if (fileStr.at(j) == charToCheck) {
				charCount++;
			}
		}

		//Adds that char and its count into parallel vectors.
		charVector.push_back(charToCheck);
		charCountVector.push_back(charCount);


	}

	//Loops through vectors and gets rid of duplicate chars.
	eraseDuplicates(charVector, charCountVector);

	//Prints out final results.
	cout << "-------------------------------------------------------------------\n";
	cout << "The statistics for the string \"" << fileStr << "\" are as follows..\n";
	for (int i = 0; i < charVector.size(); i++) {
		cout << charVector.at(i) << ": ";
		int innerLoopCheck = charCountVector.at(i);
		for (int j = 0; j < innerLoopCheck; j++) {
			cout << "*";
		}
		cout << endl;
	}
	cout << "-------------------------------------------------------------------\n";

}

//Method for erasing duplicate chars.
void eraseDuplicates(vector<char> &charVector, vector<int> &charCountVector) {

	for (int i = 0; i < charVector.size(); i++) {
		char duplicateCheck = charVector.at(i); //Gets a char to test for duplicates with.
		for (int k = 0; k < charVector.size(); k++) { //Loops through the vector erasing any duplicates.
			if (charVector.at(k) == duplicateCheck && i < k) {
				charVector.erase(charVector.begin() + k); //Erases duplicate in char vector.
				charCountVector.erase(charCountVector.begin() + k); //Erases duplicate in char count vector.
			}
		}
	}
}
