/******************************
*  Programmer : Sean Vaughan  *
*      CIS 278 - Mansour      *
*     Chapter 21 : 21.11      *
*******************************/
#include "pch.h"
#include <iostream>
#include <string>
#include <vector>

using namespace std;

//Prototypes
void printStatistics(string userStr);
void eraseDuplicates(vector<char> &charVector, vector<int> &charCountVector);

int main()
{

	//Create string object and get input from the user to fill it.
	//string userString;
	string userString;
	cout << "Please enter a string\n";
	getline(cin, userString);

	//Call method to print out string statistics.
	printStatistics(userString);

}

void printStatistics(string userStr) {

	//Create vectors to hold different chars and char counts.
	vector <char> charVector;
	vector <int> charCountVector;

	//Loops through user string to get chars and their counts.
	for (int i = 0; i < userStr.size(); i++) {

		//Gets a char to work with and assigns initial count to 0.
		char charToCheck = userStr.at(i);
		int charCount = 0;

		//Loops through the string to get how many times the char appears in the string.
		for (int j = 0; j < userStr.size(); j++) {
			if (userStr.at(j) == charToCheck) {
				charCount++;
			}
		}

		//Adds that char and its count into parallel vectors.
		charVector.push_back(charToCheck);
		charCountVector.push_back(charCount);


	}

	//Loops through vectors and gets rid of duplicate chars.
	eraseDuplicates(charVector, charCountVector);

	//Prints out final results.
	cout << "-------------------------------------------------------------------\n";
	cout << "The statistics for the string \"" << userStr << "\" are as follows..\n";
	for (int i = 0; i < charVector.size(); i++) {
		cout << "The char '" << charVector.at(i) << "' appears " << charCountVector.at(i) << " times.\n";
	}
	cout << "-------------------------------------------------------------------\n";

}

//Method for erasing duplicate chars.
void eraseDuplicates(vector<char> &charVector, vector<int> &charCountVector) {

	for (int i = 0; i < charVector.size(); i++) {
		char duplicateCheck = charVector.at(i); //Gets a char to test for duplicates with.
		for (int k = 0; k < charVector.size(); k++) { //Loops through the vector erasing any duplicates.
			if (charVector.at(k) == duplicateCheck && i < k) {
				charVector.erase(charVector.begin() + k); //Erases duplicate in char vector.
				charCountVector.erase(charCountVector.begin() + k); //Erases duplicate in char count vector.
			}
		}
	}
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
