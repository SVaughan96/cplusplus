/* * * * * * * * * * * * * * * * * *
 * Programmed By : Sean Vaughan    *
 * CIS 278 - Mansour               *
 * Chapter 4 - 4.14                *
 * * * * * * * * * * * * * * * * * */


#include "pch.h"
#include <iostream>

//Declare optional global contants
int QUIT = -1;
int MIN_ACC_NUM = 1;

//Method to get a valid account number from user.
int getAccountNum() 
{
	int newValue;

	std::cout << "\nEnter account number (-1 to quit): ";
	std::cin >> newValue;

	//Makes sure the user enters a valid account number.
	while (newValue < MIN_ACC_NUM)
	{
		if (newValue == QUIT)//Exits if the user enters -1.
		{
			break;
		}
		else
		{
			std::cout << "\nPlease enter a valid account number: ";
			std::cin >> newValue;
		}
	}
	return newValue;
}

//Method to get the beginning account balance from the user.
double getBeginningBalance()
{
	double newValue;

	std::cout << "Enter beginning balance: ";
	std::cin >> newValue;

	//Makes sure the user enters a number greater than 0.
	while (newValue < 1)
	{
		std::cout << "\nPlease enter a valid balance(Number must be greater than 0): ";
		std::cin >> newValue;
	}

	return newValue;

}

//Method to get the total charge amount from user.
double getTotalCharges()
{
	double newValue;

	std::cout << "Enter total charges: ";
	std::cin >> newValue;

	//Makes sure the user enters a number greater than 0.
	while (newValue < 1)
	{
		std::cout << "\nPlease enter a valid charge amount(Number must be greater than 0): ";
		std::cin >> newValue;
	}

	return newValue;


}

//Method to get the total credits from the user.
double getTotalCredits()
{
	double newValue;

	std::cout << "Enter total credits: ";
	std::cin >> newValue;

	//Makes sure the user enters a number greater than 0.
	while (newValue < 1)
	{
		std::cout << "\nPlease enter a valid credit amount(Number must be greater than 0): ";
		std::cin >> newValue;
	}

	return newValue;


}

//Gets a valid credit limit from user.
double getCreditLimit()
{
	double newValue;

	std::cout << "Enter credit limit: ";
	std::cin >> newValue;

	//Makes sure the user enters a number greater than 0.
	while (newValue < 1)
	{
		std::cout << "\nPlease enter a valid credit limit(Number must be greater than 0): ";
		std::cin >> newValue;
	}

	return newValue;


}

//Method to determine the accounts new balance.
double getNewBalance(double beginningBal, double totalCharge, double totalCredit)
{
	double newBal;

	newBal = (beginningBal + totalCharge - totalCredit);

	return newBal;
}

//Method for displaying info for exceeding the credit limit.
void displayCreditExceeded(int accNum, double credLimit, double newBal)
{
	std::cout << "Account      : " << accNum << "\n";
	std::cout << "Credit Limit : " << credLimit << "\n";
	std::cout << "Balance      : " << newBal << "\n";
	std::cout << "Credit Limit Exceeded.\n";
}

//---------------------MAIN-------------------------
int main()
{
	//Declare All Variables
	int accountNum = 0;
	double beginningBalance, totalCharges, totalCredits, creditLimit, newBalance;
	
	//While statement to loop through program.
	while (accountNum != QUIT)//QUIT = Sentinel value to quit program
	{
		accountNum = getAccountNum();
		if (accountNum != QUIT)//If account number is valid, program continues on.
		{
			//Gets user inputs for beginning balace, total charges, credits, and a credit limit.
			beginningBalance = getBeginningBalance();
			totalCharges = getTotalCharges();
			totalCredits = getTotalCredits();
			creditLimit = getCreditLimit();
			newBalance = getNewBalance(beginningBalance, totalCharges, totalCredits);

			//Displays the new balance.
			std::cout << "\nNew balance is " << newBalance << ".\n";

			//Displays a message to user if they have exceeded the credit limit.
			if (newBalance > creditLimit)
			{
				displayCreditExceeded(accountNum, creditLimit, newBalance);
			}
		}
	}

	std::cout << "\nThanks for using this program!\n";

}




// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

