/* * * * * * * * * * * * * * * 
 * Programmer : Sean Vaughan *
 * CIS 278 - Mansour         *
 * Chapter 4 - Exercise 4.15 *
 * * * * * * * * * * * * * * */

#include "pch.h"
#include <iostream>

//Declare global constants
int BASE_LEAVE_PER_WEEK = 2;
double PERCENT_OF_HOURS_WORKED = 0.10;
int QUIT = -1;

//Method for getting total hours worked.
double getHoursWorked()
{
	double newValue;

	std::cout << "\nEnter number of hours worked (-1 to end) : ";
	std::cin >> newValue;

	//Makes sure number is greater than 0.
	while (newValue < 1)
	{
		if (newValue == QUIT)//Exits program if user input is -1.
		{
			break;
		}
		else
		{
			std::cout << "\nPlease enter a valid amount of hours worked.\n";
			std::cin >> newValue;
		}
	}

	return newValue;
}

//Method to calculate accrued leave based on number of hours entered by user.
double determineAccruedLeave(double hours)
{
	double newValue;

	newValue = BASE_LEAVE_PER_WEEK;

	newValue += (hours * PERCENT_OF_HOURS_WORKED);

	return newValue;
}

//---------------------------MAIN--------------------------
int main()
{
    //Declare local variables.
	double hoursWorked = 0;
	double accruedLeave;

	//Loops through program.
	while (hoursWorked != QUIT)
	{
		hoursWorked = getHoursWorked();
		if (hoursWorked != QUIT)//If user doesn't enter -1 goes through with program.
		{
			//Calls method to calculate the accrued leave then we display it.
			accruedLeave = determineAccruedLeave(hoursWorked);
			std::cout << "Accrued Leave: " << accruedLeave << " hours.\n";
		}
	}

	std::cout << "Thanks for using this program!\n";

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
