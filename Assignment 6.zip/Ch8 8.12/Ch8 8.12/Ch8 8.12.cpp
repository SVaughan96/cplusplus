/******************************
*  Programmer : Sean Vaughan  *
*       CIS 278 - Mansour     *
*  Chapter 8 - Exercise 8.12  *
*******************************/

#include "pch.h"
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <thread>
#include <chrono>

using namespace std;

//Constant for the size of the course.
const int TRACK_SIZE = 70;

//Prototypes
void displayTrackValues(int* tortPos, int* harePos);
void moveTort(int *tortPos);
void moveHare(int *harePos);
void winnerMessage(int *tortPos, int *harePos);


//---------------- MAIN -----------------
int main()
{
	//Initial tortoise and hare position variables.
	int tortPos = 0;
	int harePos = 0;

	//Initial start
	displayTrackValues(&tortPos, &harePos);

	//Race start up message.
	cout << "BANG !!!!!\n";
	cout << "AND THEY'RE OFF !!!!!\n";

	//Loops through race.
	do {
		//Gets tortoise and hare moves.
		moveTort(&tortPos);
		moveHare(&harePos);
	
		//Displays the track and the racer's positions on it.
		displayTrackValues(&tortPos, &harePos);

		//Sleeps for 1 seconds.
		std::chrono::milliseconds timespan(1000);
		std::this_thread::sleep_for(timespan);

	} while (tortPos < 70 && harePos < 70);

	//Displays winner message.
	winnerMessage(&tortPos, &harePos);

}

//Method for displaying winner message
void winnerMessage(int *tortPos, int *harePos) {
	if (*tortPos >= 70 && *harePos >= 70) { //Tie
		cout << "Well it looks like it's a tie!\n";
	}
	else if (*tortPos >= 70) { //Tortoise wins
		cout << "TORTOISE WINS!!! YAY!!!\n";
	}
	else if (*harePos >= 70) { //Hare wins
		cout << "Hare wins. Yuck.\n";
	}
}

//Method for tortoise moves
void moveTort(int *tortPos) {
	int num;

	srand(time(NULL));

	num = rand() % 100 + 1;

	if (num <= 50) { //Fast Plod
		cout << "\nTortoise used Fast plod\n";
		*tortPos = *tortPos + 3;
	}
	else if (num <= 67 && num > 50) {  //Slip
		cout << "\nThe tortoise slipped and fell back some!\n";
		*tortPos = *tortPos - 6;
		if (*tortPos < 0) {
			*tortPos = 0;
		}
	}
	else { //Slow Plod
		cout << "\nTortoise used Slow plod!\n";
		*tortPos = *tortPos + 1;
	}


}

//Method for determining hare move.
void moveHare(int *harePos) {
	 
	int num;

	srand(time(NULL));

	num = rand() % 100 + 1;

	if (num <= 38) { //Sleep
		cout << "The hare fell asleep.\n";
		*harePos = *harePos;
	}
	else if (num <= 54 && num > 38) { //Big Hop
		cout << "The hare used Big hop!\n";
		*harePos = *harePos + 11;
	}
	else if (num > 54 && num <= 70) { //Big slip
		cout << "The hare slipped big time!\n";
		*harePos = *harePos - 9;
		if (*harePos < 0) {
			*harePos = 0;
		}
	}
	else if (num > 70 && num <= 90) { //Small hop
		cout << "The hare used Small Hop!\n";
		*harePos = *harePos + 1;
	}
	else { //Small slip
		cout << "The hare slipped a little bit!\n";
		*harePos = *harePos - 2;
		if (*harePos < 0) {
			*harePos = 0;
		}
	}
}

//Method for displaying the track.
void displayTrackValues(int* tortPos, int* harePos) {

	for (int i = 0; i < TRACK_SIZE; i++) { 
		if (i == *tortPos && i == *harePos) { //Tortoise and hare on same position
			cout << "OUCH!!!";
		}
		else if (i == *tortPos) { //Tortoise position
			cout << "T";
		}
		else if (i == *harePos) { //Hare position
			cout << "H";
		}
		else{ //Empty position
			cout << "-";
		}

	}
	cout << endl;
	
}

