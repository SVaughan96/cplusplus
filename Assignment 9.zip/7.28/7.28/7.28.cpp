/******************************
*  Programmer : Sean Vaughan  *
*      CIS278 - Mansour       *
*      Chapter 7 : 7.28       *
******************************/

#include "pch.h"
#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

//Prototypes
bool testPalindrome(string str);
string eraseNonLetters(string str);

//--------- MAIN -----------
int main()
{
	//Create bool and strings.
	bool isPalindrome;
	string userString;
	string modifiedString;
	
	//Get palindrome from user then reads a whole line into a string.
	cout << "\nPlease enter a word or phrase that could be a palindome.\n";
	getline(cin, userString);

	//Erases all non alphabetical chars.
	modifiedString = eraseNonLetters(userString);

	//Tests if reversed string is a palindrome.
	isPalindrome = testPalindrome(modifiedString);

	if (isPalindrome) { //If string is a palindrome.
		cout << "\"" << userString << "\" is a palindrome.\n";
	}
	else if (!isPalindrome) { //If string in to a palindrome.
		cout << "\"" << userString << "\" is not a palindrome.\n";
	}
}
//-------- END MAIN ---------

//Method to erase all non alphabetical chars.
string eraseNonLetters(string str)
{
	//Gets rid of whitespaces
	str.erase(remove_if(str.begin(), str.end(), isspace), str.end());
	
	//Gets rid of commas
	string strCheck1(str.size(), '0');
	strCheck1.erase(remove_copy(str.begin(), str.end(), strCheck1.begin(), ','), strCheck1.end());
	
	//Gets rid of question marks
	string strCheck2(strCheck1.size(), '0');
	strCheck2.erase(remove_copy(strCheck1.begin(), strCheck1.end(), strCheck2.begin(), '?'), strCheck2.end());
	
	//Gets rid of exclamation points
	string strCheck3(strCheck2.size(), '0');
	strCheck3.erase(remove_copy(strCheck2.begin(), strCheck2.end(), strCheck3.begin(), '!'), strCheck3.end());

	return strCheck3;
}

//Compares reversed string to orginal to check if identical.
bool testPalindrome(string str)
{
	//Creates a copy of original string for comparison.
	string originalString = str;

	//Reverses contents of user string.
	reverse(str.begin(), str.end());

	if (str == originalString) { //Is a palindrome.
	    return true;
	}
	else if(str != originalString){ //Is not a palindrome.
		return false;
	}
}

