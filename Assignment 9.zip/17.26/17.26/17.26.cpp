/******************************
*  Programmer : Sean Vaughan  *
*      CIS 278 - Mansour      *
*     Chapter 17 - 17.26      *
*******************************/

#include "pch.h"
#include <iostream>
#include <exception>

using namespace std;

int main()
{
	//Try-catch statement
	try
	{
		//Gets number from user
		int number;
		cout << "Enter a number.\n";
		cin >> number;

		//Throws an exception no matter what
		throw 1;
		
	}
	catch(int e)
	{
		cout << "Error exception number: " << e << endl;
		try {
			//Throws a 2nd exception
			throw runtime_error{ "Also Runtime error occured.\n" };
		}
		catch (runtime_error e)
		{
			cout << e.what();
			try {
				//Throws a 3rd exception
				throw exception{ "A 3rd Random Exception for fun.\n" };
			}
			catch (exception& e) {
				cout << e.what();
			}
		}
	}
	
	
}

