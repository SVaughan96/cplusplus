/******************************
*  Programmer : Sean Vaughan  *
*      CIS 278 - Mansour      *
*      Chapter 7 - 7.32       *
*******************************/

#include "pch.h"
#include <iostream>
#include <array>
#include <stdlib.h>

using namespace std;

//Start point for highest value search;
int const ARRAY_START_ELEMENT = 1;
//End point for highest value search.
int const ARRAY_END_ELEMENT = 9;


//Prototypes
int recursiveMaximum(int myArray[], int start, int end);

int main()
{
	//Creates an array with 10 elements and fills it.
	size_t const SIZE = 10;
	int myArray[SIZE] = { 10, 15, 1, 100, 5, 101, 2, 3, 1000, 500 };

	//Gets highest number out of the array.
	int highestNum = recursiveMaximum(myArray, ARRAY_START_ELEMENT, ARRAY_END_ELEMENT);

	//Displays highest num.
	cout << "The highest number in the array is : " << highestNum << endl;
}

//Method for finding highest array element.
int recursiveMaximum(int myArray[], int start, int end)
{
	int highNum = myArray[start - 1];
	for (int i = start; i <= end; i++) {
		if (highNum < myArray[i]) {
			highNum = myArray[i];
		}
	}
	return highNum;
}
